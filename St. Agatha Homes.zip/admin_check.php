<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: login.html");
    exit();
}

// Verify user is admin
try {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT user_id FROM Users WHERE user_id = ? AND role = 'admin'");
    $stmt->execute([$_SESSION['user_id']]);
    if (!$stmt->fetch()) {
        header("Location: index.php");
        exit();
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>