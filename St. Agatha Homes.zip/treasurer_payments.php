<?php
session_start();
require_once 'db_connection.php';

// Check if user is treasurer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'treasurer') {
    header("Location: login.html");
    exit();
}

// Get all payments
$payments = [];
$total_collected = 0;
$pending_count = 0;

try {
    $conn = getDBConnection();
    
    // Get all payments with user info
    $stmt = $conn->query("
        SELECT p.*, u.name as user_name, u.email, f.name as fee_name 
        FROM Payments p
        JOIN Users u ON p.user_id = u.user_id
        LEFT JOIN FeeTypes f ON p.fee_type_id = f.fee_type_id
        ORDER BY p.date DESC
    ");
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get totals
    $stmt = $conn->query("SELECT SUM(amount) as total FROM Payments WHERE status = 'paid'");
    $total_collected = $stmt->fetchColumn() ?: 0;
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM Payments WHERE status = 'pending'");
    $pending_count = $stmt->fetchColumn() ?: 0;

} catch (PDOException $e) {
    $error = "Error loading payments: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasurer Portal - Payments</title>
    <style>
        /* (Keep all your existing header, nav, and footer styles) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            color: #2f4f2f;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background-color: #2e8b57;
            color: white;
            padding: 30px 20px 20px;
            text-align: center;
            position: relative;
        }

        header h1 {
            font-family: 'Great Vibes', cursive;
            font-size: 3rem;
            margin: 0;
        }

        .user-welcome {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .user-welcome a {
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            font-weight: bold;
            background-color: #f08080;
            color: white;
            border: none;
            transition: opacity 0.3s;
        }

        .user-welcome a:hover {
            opacity: 0.9;
        }

        .nav {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            background-color: #3cb371;
            padding: 10px 0;
        }

        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .nav a:hover {
            background-color: #2e8b57;
        }

        .nav a.current {
            background-color: #2e8b57;
            font-weight: bold;
        }

        /* Bookings Specific Styles */
        .bookings-header {
            text-align: center;
            margin: 30px 0;
            padding: 20px;
            background-color: #e0f5e0;
            border-radius: 8px;
        }

        .bookings-header h2 {
            color: #2e8b57;
            margin-top: 0;
            font-size: 2rem;
        }

        .tabs {
            display: flex;
            border-bottom: 2px solid #3cb371;
            margin-bottom: 20px;
        }

        .tab {
            padding: 10px 20px;
            cursor: pointer;
            background: #e0f5e0;
            margin-right: 5px;
            border-radius: 5px 5px 0 0;
        }

        .tab.active {
            background: #3cb371;
            color: white;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .booking-card {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            transition: transform 0.3s;
        }

        .booking-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .booking-image {
            width: 150px;
            height: 150px;
            background-size: cover;
            background-position: center;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .booking-details {
            flex: 1;
            min-width: 250px;
        }

        .booking-details h3 {
            color: #2e8b57;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .booking-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin: 15px 0;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #5a8f5a;
        }

        .status {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
        }

        .status.confirmed {
            background-color: #d4edda;
            color: #155724;
        }

        .status.pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status.cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }

        .action-btns {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #3cb371;
            color: white;
        }

        .btn-danger {
            background-color: #f08080;
            color: white;
        }

        .btn-outline {
            background-color: transparent;
            border: 1px solid #3cb371;
            color: #3cb371;
        }

        .amenity-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .amenity-item {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s;
        }

        .amenity-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .amenity-icon {
            font-size: 2rem;
            color: #2e8b57;
            margin-bottom: 10px;
        }

        .no-bookings {
            text-align: center;
            padding: 40px;
            background-color: #f8fff8;
            border-radius: 8px;
            border: 1px dashed #c0eec0;
        }

        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            background-color: #2e8b57;
            color: white;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            header h1 {
                font-size: 2.2rem;
            }

            .user-welcome {
                position: static;
                justify-content: center;
                margin-top: 10px;
            }

            .nav {
                flex-direction: column;
                align-items: center;
            }

            .nav a {
                width: 90%;
                text-align: center;
            }

            .booking-card {
                flex-direction: column;
            }

            .booking-image {
                width: 100%;
                height: 200px;
            }
        /* Treasurer Specific Styles */
        .summary-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin: 30px 0;
        }

        .summary-card {
            flex: 1;
            min-width: 200px;
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .summary-card h3 {
            color: #2e8b57;
            margin-top: 0;
        }

        .summary-value {
            font-size: 2rem;
            font-weight: bold;
            margin: 10px 0;
        }

        .total-collected {
            color: #2e8b57;
        }

        .pending-payments {
            color: #ffc107;
        }

        .action-btns {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 15px;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #3cb371;
            color: white;
        }

        .btn-primary:hover {
            background-color: #2e8b57;
        }

        .btn-outline {
            background-color: transparent;
            border: 1px solid #3cb371;
            color: #3cb371;
        }

        .btn-outline:hover {
            background-color: #f0f0f0;
        }

        .receipt-img {
            max-width: 100px;
            max-height: 100px;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .receipt-img:hover {
            transform: scale(1.5);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.8);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            max-width: 80%;
            max-height: 80%;
            overflow: auto;
        }

        .modal-content img {
            max-width: 100%;
            max-height: 80vh;
        }
    </style>
</head>
<body>
    <header>
        <h1>St. Agatha Homes</h1>
        <p>Treasurer Portal</p>
        
        <div class="user-welcome">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?> (Treasurer)</span>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <div class="nav">
        <a href="treasurer_dashboard.php">Dashboard</a>
        <a href="treasurer_payments.php" class="current">Payments</a>
        <a href="treasurer_reports.php">Reports</a>
    </div>

    <div class="container">
        <div class="payments-header">
            <h2><i class="fas fa-money-check-alt"></i> Payment Management</h2>
            <p>Review and verify resident payments</p>
        </div>

        <div class="summary-cards">
            <div class="summary-card">
                <h3>Total Collected</h3>
                <div class="summary-value total-collected">₱<?php echo number_format($total_collected, 2); ?></div>
                <p>All verified payments</p>
            </div>
            
            <div class="summary-card">
                <h3>Pending Verification</h3>
                <div class="summary-value pending-payments"><?php echo $pending_count; ?></div>
                <p>Payments awaiting approval</p>
            </div>
        </div>

        <h2><i class="fas fa-list"></i> All Payments</h2>
        <table id="paymentsTable" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Resident</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Receipt</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($payments as $payment): ?>
                    <tr>
                        <td><?php echo date('M j, Y', strtotime($payment['date'])); ?></td>
                        <td>
                            <?php echo htmlspecialchars($payment['user_name']); ?><br>
                            <small><?php echo htmlspecialchars($payment['email']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($payment['fee_name'] ?: 'Maintenance Fee'); ?></td>
                        <td>₱<?php echo number_format($payment['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($payment['method']); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo strtolower($payment['status']); ?>">
                                <?php echo ucfirst($payment['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if(!empty($payment['receipt_path'])): ?>
                                <img src="<?php echo htmlspecialchars($payment['receipt_path']); ?>" 
                                     alt="Receipt" 
                                     class="receipt-img"
                                     onclick="showReceipt('<?php echo htmlspecialchars($payment['receipt_path']); ?>')">
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($payment['status'] == 'pending'): ?>
                                <div class="action-btns">
                                    <button class="btn btn-primary" 
                                            onclick="updatePaymentStatus(<?php echo $payment['payment_id']; ?>, 'paid')">
                                        Approve
                                    </button>
                                    <button class="btn btn-outline" 
                                            onclick="updatePaymentStatus(<?php echo $payment['payment_id']; ?>, 'late')">
                                        Reject
                                    </button>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div id="receiptModal" class="modal">
        <div class="modal-content">
            <button onclick="document.getElementById('receiptModal').style.display='none'" 
                    style="float:right; margin-bottom:10px;">
                Close
            </button>
            <img id="modalReceiptImg" src="" alt="Payment Receipt">
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> St. Agatha Homes. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#paymentsTable').DataTable({
                responsive: true
            });
        });

        function showReceipt(receiptPath) {
            const modal = document.getElementById('receiptModal');
            const img = document.getElementById('modalReceiptImg');
            img.src = receiptPath;
            modal.style.display = 'flex';
        }

        function updatePaymentStatus(paymentId, status) {
            const action = status === 'paid' ? 'approve' : 'reject';
            if(confirm(`Are you sure you want to ${action} this payment?`)) {
                fetch('update_payment_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        payment_id: paymentId,
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert(`Payment ${action}d successfully`);
                        window.location.reload();
                    } else {
                        alert(data.message || `Failed to ${action} payment`);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred');
                });
            }
        }
    </script>
</body>
</html>