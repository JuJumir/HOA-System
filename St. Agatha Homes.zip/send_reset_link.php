<?php
require 'vendor/autoload.php';
require 'db_connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    
    try {
        $conn = getDBConnection();
        // 1. Verify user exists
        $stmt = $conn->prepare("SELECT user_id FROM Users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            header("Location: forgot_password.php?message=Email not found&status=error");
            exit();
        }

        // 2. Generate and store token
        $token = bin2hex(random_bytes(32));
        $expires = date("Y-m-d H:i:s", time() + 3600); // 1 hour expiration

        // Debug output
        error_log("Attempting to store token for user {$user['user_id']}: $token");

        // 3. Insert token (with transaction for safety)
        $conn->beginTransaction();
        
        try {
            $stmt = $conn->prepare("INSERT INTO PasswordResetTokens (user_id, token, expires_at) VALUES (?, ?, ?)");
            $stmt->execute([$user['user_id'], $token, $expires]);
            
            // Verify insertion
            $insertId = $conn->lastInsertId();
            if (!$insertId) {
                throw new Exception("Token insertion failed");
            }
            
            $conn->commit();
            error_log("Token stored successfully with ID: $insertId");
            
        } catch (Exception $e) {
            $conn->rollBack();
            error_log("Database error: " . $e->getMessage());
            throw new Exception("Could not save reset token");
        }

        // 4. Send email
        $mail = new PHPMailer(true);
        
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'redstiron1@gmail.com';
        $mail->Password = 'fuje nzgk mkoj vkwc';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // Email content - Using rawurlencode() for the folder name
        $resetLink = "http://localhost/St.%20Agatha%20Homes/reset_password.php?token=" . urlencode($token);
        
        $mail->setFrom('no-reply@stagathahomessupport.com', 'St. Agatha Homes Support');
        $mail->addAddress($email);
        $mail->Subject = 'Password Reset Request';
        $mail->isHTML(true);
        $mail->Body = "
            <h2>Password Reset</h2>
            <p>Click this link to reset your password (expires in 1 hour):</p>
            <p><a href='$resetLink'>Reset Password</a></p>
            <p><small>Can't click? Copy this URL: $resetLink</small></p>
            <p>If you didn't request this, please ignore this email.</p>
        ";

        $mail->send();
        header("Location: forgot_password.php?message=Reset link sent to your email&status=success");
        
    } catch (Exception $e) {
        error_log("SYSTEM ERROR: " . $e->getMessage());
        header("Location: forgot_password.php?message=System error. Please try again later.&status=error");
    }
}
?>