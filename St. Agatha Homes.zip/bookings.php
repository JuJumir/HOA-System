<?php
session_start();
require_once 'db_connection.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Get user bookings
$bookings = [];
$available_slots = [];
try {
    $conn = getDBConnection();
    
    // Get user's bookings
    $stmt = $conn->prepare("
        SELECT b.booking_id, a.name as amenity_name, b.booking_date, 
               b.start_time, b.end_time, b.status, a.image_url, a.icon_class
        FROM Bookings b
        JOIN Amenities a ON b.amenity_id = a.amenity_id
        WHERE b.user_id = :user_id
        ORDER BY b.booking_date DESC, b.start_time DESC
    ");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get available time slots for booking (next 7 days)
    $stmt = $conn->query("
        SELECT a.amenity_id, a.name, a.image_url, a.icon_class
        FROM Amenities a
        WHERE a.is_active = TRUE
    ");
    $available_slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "Error loading bookings: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Agatha Homes - My Bookings</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            color: #2f4f2f;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background-color: #2e8b57;
            color: white;
            padding: 30px 20px 20px;
            text-align: center;
            position: relative;
        }

        header h1 {
            font-family: 'Great Vibes', cursive;
            font-size: 3rem;
            margin: 0;
        }

        .user-welcome {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .user-welcome a {
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            font-weight: bold;
            background-color: #f08080;
            color: white;
            border: none;
            transition: opacity 0.3s;
        }

        .user-welcome a:hover {
            opacity: 0.9;
        }

        .nav {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            background-color: #3cb371;
            padding: 10px 0;
        }

        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .nav a:hover {
            background-color: #2e8b57;
        }

        .nav a.current {
            background-color: #2e8b57;
            font-weight: bold;
        }

        /* Bookings Specific Styles */
        .bookings-header {
            text-align: center;
            margin: 30px 0;
            padding: 20px;
            background-color: #e0f5e0;
            border-radius: 8px;
        }

        .bookings-header h2 {
            color: #2e8b57;
            margin-top: 0;
            font-size: 2rem;
        }

        .tabs {
            display: flex;
            border-bottom: 2px solid #3cb371;
            margin-bottom: 20px;
        }

        .tab {
            padding: 10px 20px;
            cursor: pointer;
            background: #e0f5e0;
            margin-right: 5px;
            border-radius: 5px 5px 0 0;
        }

        .tab.active {
            background: #3cb371;
            color: white;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .booking-card {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            transition: transform 0.3s;
        }

        .booking-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .booking-image {
            width: 150px;
            height: 150px;
            background-size: cover;
            background-position: center;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .booking-details {
            flex: 1;
            min-width: 250px;
        }

        .booking-details h3 {
            color: #2e8b57;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .booking-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin: 15px 0;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #5a8f5a;
        }

        .status {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
        }

        .status.confirmed {
            background-color: #d4edda;
            color: #155724;
        }

        .status.pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status.cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }

        .action-btns {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #3cb371;
            color: white;
        }

        .btn-danger {
            background-color: #f08080;
            color: white;
        }

        .btn-outline {
            background-color: transparent;
            border: 1px solid #3cb371;
            color: #3cb371;
        }

        .amenity-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .amenity-item {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s;
        }

        .amenity-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .amenity-icon {
            font-size: 2rem;
            color: #2e8b57;
            margin-bottom: 10px;
        }

        .no-bookings {
            text-align: center;
            padding: 40px;
            background-color: #f8fff8;
            border-radius: 8px;
            border: 1px dashed #c0eec0;
        }

        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            background-color: #2e8b57;
            color: white;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            header h1 {
                font-size: 2.2rem;
            }

            .user-welcome {
                position: static;
                justify-content: center;
                margin-top: 10px;
            }

            .nav {
                flex-direction: column;
                align-items: center;
            }

            .nav a {
                width: 90%;
                text-align: center;
            }

            .booking-card {
                flex-direction: column;
            }

            .booking-image {
                width: 100%;
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>St. Agatha Homes</h1>
        <p>Community Portal</p>
        
        <div class="user-welcome">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <div class="nav">
        <a href="index.php">Home</a>
        <a href="events.php">Events</a>
        <a href="amenities.php">Amenities</a>
        <a href="bookings.php" class="current">Bookings</a>
        <a href="payments.php">Payments</a>
    </div>

    <div class="container">
        <div class="bookings-header">
            <h2><i class="fas fa-calendar-check"></i> My Bookings</h2>
            <p>Manage your amenity reservations and book new time slots</p>
        </div>

        <div class="tabs">
            <div class="tab active" data-tab="current">Current Bookings</div>
            <div class="tab" data-tab="new">Book Amenity</div>
        </div>

        <div class="tab-content active" id="current-tab">
            <?php if(!empty($bookings)): ?>
                <?php foreach($bookings as $booking): ?>
                    <div class="booking-card">
                        <div class="booking-image" style="background-image: url('<?php echo htmlspecialchars($booking['image_url'] ?: 'images/default-amenity.jpg'); ?>')"></div>
                        <div class="booking-details">
                            <h3>
                                <i class="<?php echo htmlspecialchars($booking['icon_class'] ?: 'fas fa-star'); ?>"></i>
                                <?php echo htmlspecialchars($booking['amenity_name']); ?>
                            </h3>
                            
                            <div class="booking-meta">
                                <div class="meta-item">
                                    <i class="fas fa-calendar-day"></i>
                                    <?php echo date('M j, Y', strtotime($booking['booking_date'])); ?>
                                </div>
                                <div class="meta-item">
                                    <i class="fas fa-clock"></i>
                                    <?php echo date('g:i A', strtotime($booking['start_time'])) . ' - ' . date('g:i A', strtotime($booking['end_time'])); ?>
                                </div>
                                <div class="meta-item">
                                    <i class="fas fa-info-circle"></i>
                                    Status: <span class="status <?php echo strtolower($booking['status']); ?>"><?php echo htmlspecialchars($booking['status']); ?></span>
                                </div>
                            </div>
                            
                            <div class="action-btns">
                                <?php if($booking['status'] == 'Confirmed' || $booking['status'] == 'Pending'): ?>
                                    <button class="btn btn-danger" onclick="cancelBooking(<?php echo $booking['booking_id']; ?>)">
                                        <i class="fas fa-times"></i> Cancel
                                    </button>
                                <?php endif; ?>
                                <a href="booking_details.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-outline">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-bookings">
                    <i class="fas fa-calendar-times" style="font-size: 3rem; color: #3cb371; margin-bottom: 15px;"></i>
                    <h3>No Bookings Found</h3>
                    <p>You haven't made any amenity bookings yet.</p>
                    <button class="btn btn-primary" onclick="switchTab('new')">
                        <i class="fas fa-plus"></i> Book an Amenity
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <div class="tab-content" id="new-tab">
            <h3><i class="fas fa-plus-circle"></i> Book a Community Amenity</h3>
            <p>Select an amenity to check availability and book a time slot</p>
            
            <?php if(!empty($available_slots)): ?>
                <div class="amenity-grid">
                    <?php foreach($available_slots as $amenity): ?>
                        <div class="amenity-item" onclick="window.location.href='book_amenity.php?id=<?php echo $amenity['amenity_id']; ?>'">
                            <div class="amenity-icon">
                                <i class="<?php echo htmlspecialchars($amenity['icon_class'] ?: 'fas fa-star'); ?>"></i>
                            </div>
                            <h3><?php echo htmlspecialchars($amenity['name']); ?></h3>
                            <p>Click to view available time slots</p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="no-bookings">
                    <i class="fas fa-ban" style="font-size: 3rem; color: #f08080; margin-bottom: 15px;"></i>
                    <h3>No Amenities Available</h3>
                    <p>There are currently no amenities available for booking.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> St. Agatha Homes. All rights reserved.</p>
    </footer>

    <script>
        // Tab switching
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                this.classList.add('active');
                document.getElementById(`${this.dataset.tab}-tab`).classList.add('active');
            });
        });

        function switchTab(tabName) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');
            document.getElementById(`${tabName}-tab`).classList.add('active');
        }

        function cancelBooking(bookingId) {
            if(confirm('Are you sure you want to cancel this booking?')) {
                fetch('cancel_booking.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        booking_id: bookingId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert('Booking cancelled successfully');
                        window.location.reload();
                    } else {
                        alert(data.message || 'Failed to cancel booking');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the booking');
                });
            }
        }
    </script>
</body>
</html>