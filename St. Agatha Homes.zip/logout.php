<?php
session_start();

// Include the audit log function
require_once 'audit_log.php';

if (isset($_SESSION['user_id'])) {
    // Log the logout action
    logAudit($_SESSION['user_id'], 'Logout');
    
    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
}

// Redirect to login page
header("Location: login.php");
exit();
?>