<?php
function getDBConnection() {
    $host = 'localhost';
    $dbname = 'hoa';
    $username = 'root';
    $password = ''; // Your actual password here if you have one

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}
?>