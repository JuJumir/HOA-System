<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Get user's payment history
$payments = [];
$balance = 0;
$gcash_qr = 'images/gcash_qr.png'; // Path to your GCash QR code
$gcash_number = '09123456789'; // Your community GCash number

try {
    $conn = getDBConnection();
    
    // Get payment history
    $stmt = $conn->prepare("
        SELECT p.*, f.name as fee_name 
        FROM Payments p
        LEFT JOIN FeeTypes f ON p.fee_type_id = f.fee_type_id
        WHERE p.user_id = :user_id
        ORDER BY p.date DESC
    ");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate outstanding balance
    $stmt = $conn->prepare("
        SELECT SUM(amount) as balance 
        FROM Payments 
        WHERE user_id = :user_id AND status IN ('pending', 'late')
    ");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $balance = $stmt->fetchColumn() ?: 0;

} catch (PDOException $e) {
    $error = "Error loading payments: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Agatha Homes - Payments</title>
    <style>
        /* (Keep all your existing header, nav, and footer styles) */
        body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #ffffff;
        color: #2f4f2f;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    header {
        background-color: #2e8b57;
        color: white;
        padding: 30px 20px 20px;
        text-align: center;
        position: relative;
    }

    header h1 {
        font-family: 'Great Vibes', cursive;
        font-size: 3rem;
        margin: 0;
    }

    header p {
        font-size: 1.1rem;
        margin: 5px 0 0;
    }

    .auth-buttons,
    .user-welcome {
        position: absolute;
        top: 20px;
        right: 20px;
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
    }

    .auth-buttons a,
    .user-welcome a {
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
    }

    .auth-buttons a.login {
        background-color: transparent;
        border: 2px solid white;
        color: white;
    }

    .auth-buttons a.register {
        background-color: #98fb98;
        color: #2e8b57;
        border: 2px solid #98fb98;
    }

    .auth-buttons a:hover,
    .user-welcome a:hover {
        opacity: 0.9;
    }

    .user-welcome a {
        background-color: #f08080;
        color: white;
        border: none;
    }

    .nav {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        background-color: #3cb371;
        padding: 10px 0;
    }

    .nav a {
        color: white;
        text-decoration: none;
        padding: 10px 15px;
        margin: 5px;
        border-radius: 4px;
        transition: background-color 0.3s;
    }

    .nav a:hover {
        background-color: #2e8b57;
    }

    .nav a.disabled {
        color: #ccc;
        cursor: not-allowed;
    }

    .card-container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
        margin-top: 30px;
    }

    .card {
        background-color: #f8fff8;
        border: 1px solid #c0eec0;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        padding: 20px;
        transition: transform 0.3s;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .card h3 {
        color: #2e8b57;
        margin-top: 0;
    }

    .login-message {
        text-align: center;
        margin: 20px 0;
        padding: 15px;
        background-color: #e0f5e0;
        border-left: 5px solid #3cb371;
    }

    footer {
        text-align: center;
        margin-top: 50px;
        padding: 20px;
        background-color: #2e8b57;
        color: white;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        header h1 {
            font-size: 2.2rem;
        }

        .auth-buttons,
        .user-welcome {
            position: static;
            justify-content: center;
            margin-top: 10px;
        }

        .nav {
            flex-direction: column;
            align-items: center;
        }

        .nav a {
            width: 90%;
            text-align: center;
        }

        .container {
            padding: 10px;
        }

        .card {
            padding: 15px;
        }
    }

        /* Payments Specific Styles */
        .payments-header {
            text-align: center;
            margin: 30px 0;
            padding: 20px;
            background-color: #e0f5e0;
            border-radius: 8px;
        }

        .balance-card {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .balance-amount {
            font-size: 2.5rem;
            color: #2e8b57;
            margin: 10px 0;
            font-weight: bold;
        }

        .payment-methods {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin: 30px 0;
            justify-content: center;
        }

        .method-card {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            padding: 20px;
            width: 300px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .method-card h3 {
            color: #2e8b57;
            margin-top: 0;
        }

        .qr-code {
            width: 200px;
            height: 200px;
            margin: 15px auto;
            border: 1px solid #ddd;
            padding: 10px;
            background: white;
        }

        .qr-code img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .payment-history {
            margin-top: 40px;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .payment-table th, .payment-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #c0eec0;
        }

        .payment-table th {
            background-color: #e0f5e0;
            color: #2e8b57;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
        }

        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-late {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #3cb371;
            color: white;
        }

        .btn-primary:hover {
            background-color: #2e8b57;
        }

        .copy-btn {
            background-color: #f0f0f0;
            border: 1px solid #ddd;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 5px;
        }

        .copy-btn:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <header>
        <h1>St. Agatha Homes</h1>
        <p>Community Portal</p>
        
        <div class="user-welcome">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <div class="nav">
        <a href="index.php">Home</a>
        <a href="events.php">Events</a>
        <a href="amenities.php">Amenities</a>
        <a href="bookings.php">Bookings</a>
        <a href="payments.php" class="current">Payments</a>
    </div>

    <div class="container">
        <div class="payments-header">
            <h2><i class="fas fa-money-bill-wave"></i> Payment Portal</h2>
            <p>Pay your maintenance fees and view payment history</p>
        </div>

        <div class="balance-card">
            <h3>Outstanding Balance</h3>
            <div class="balance-amount">₱<?php echo number_format($balance, 2); ?></div>
            <?php if($balance > 0): ?>
                <p>Please settle your balance at your earliest convenience.</p>
                <button class="btn btn-primary" onclick="document.getElementById('paymentMethods').scrollIntoView()">
                    Pay Now
                </button>
            <?php else: ?>
                <p>You have no outstanding balance. Thank you!</p>
            <?php endif; ?>
        </div>

        <div id="paymentMethods">
            <h2><i class="fas fa-qrcode"></i> Payment Methods</h2>
            <div class="payment-methods">
                <div class="method-card">
                    <h3><i class="fas fa-mobile-alt"></i> GCash</h3>
                    <p>Scan the QR code or send payment to:</p>
                    
                    <div class="qr-code">
                        <img src="<?php echo $gcash_qr; ?>" alt="GCash QR Code">
                    </div>
                    
                    <p>
                        <strong>GCash Number:</strong> 
                        <span id="gcashNum"><?php echo $gcash_number; ?></span>
                        <button class="copy-btn" onclick="copyToClipboard('gcashNum')">
                            <i class="far fa-copy"></i>
                        </button>
                    </p>
                    
                    <p>After payment, please upload the receipt below:</p>
                    <form action="upload_receipt.php" method="post" enctype="multipart/form-data">
                        <input type="file" name="receipt" accept="image/*,.pdf" required>
                        <input type="hidden" name="method" value="GCash">
                        <button type="submit" class="btn btn-primary" style="margin-top: 15px;">
                            <i class="fas fa-upload"></i> Upload Receipt
                        </button>
                    </form>
                </div>

                <div class="method-card">
                    <h3><i class="fas fa-university"></i> Bank Transfer</h3>
                    <p>Send payment to our bank account:</p>
                    
                    <p><strong>Bank:</strong> BDO</p>
                    <p><strong>Account Name:</strong> St. Agatha Homes Association</p>
                    <p>
                        <strong>Account Number:</strong> 
                        <span id="bankAcc">123456789012</span>
                        <button class="copy-btn" onclick="copyToClipboard('bankAcc')">
                            <i class="far fa-copy"></i>
                        </button>
                    </p>
                    
                    <p>After payment, please upload the deposit slip below:</p>
                    <form action="upload_receipt.php" method="post" enctype="multipart/form-data">
                        <input type="file" name="receipt" accept="image/*,.pdf" required>
                        <input type="hidden" name="method" value="Bank Transfer">
                        <button type="submit" class="btn btn-primary" style="margin-top: 15px;">
                            <i class="fas fa-upload"></i> Upload Receipt
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="payment-history">
            <h2><i class="fas fa-history"></i> Payment History</h2>
            <?php if(!empty($payments)): ?>
                <table class="payment-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($payments as $payment): ?>
                            <tr>
                                <td><?php echo date('M j, Y', strtotime($payment['date'])); ?></td>
                                <td><?php echo htmlspecialchars($payment['fee_name'] ?: 'Maintenance Fee'); ?></td>
                                <td>₱<?php echo number_format($payment['amount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($payment['method']); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($payment['status']); ?>">
                                        <?php echo ucfirst($payment['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No payment history found.</p>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> St. Agatha Homes. All rights reserved.</p>
    </footer>

    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            const text = element.innerText;
            
            navigator.clipboard.writeText(text).then(() => {
                alert('Copied to clipboard: ' + text);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
    </script>
</body>
</html>