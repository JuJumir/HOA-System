<?php
session_start();
require_once 'db_connection.php';

// Redirect to login if not logged in and trying to access restricted sections
if (!isset($_SESSION['user_id'])) {
    $restricted_pages = array('amenities', 'bookings', 'payments');
    $current_page = basename($_SERVER['PHP_SELF'], '.php');
    
    if (in_array($current_page, $restricted_pages)) {
        header("Location: login.html");
        exit();
    }
}

// Get upcoming events (visible to all)
$events = array();
try {
    $conn = getDBConnection();
    $stmt = $conn->query("SELECT * FROM Events WHERE date >= NOW() ORDER BY date LIMIT 3");
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error loading events: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Agatha Homes</title>
    <style>
        
        body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #ffffff;
        color: #2f4f2f;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    header {
        background-color: #2e8b57;
        color: white;
        padding: 30px 20px 20px;
        text-align: center;
        position: relative;
    }

    header h1 {
        font-family: 'Great Vibes', cursive;
        font-size: 3rem;
        margin: 0;
    }

    header p {
        font-size: 1.1rem;
        margin: 5px 0 0;
    }

    .auth-buttons,
    .user-welcome {
        position: absolute;
        top: 20px;
        right: 20px;
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
    }

    .auth-buttons a,
    .user-welcome a {
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
    }

    .auth-buttons a.login {
        background-color: transparent;
        border: 2px solid white;
        color: white;
    }

    .auth-buttons a.register {
        background-color: #98fb98;
        color: #2e8b57;
        border: 2px solid #98fb98;
    }

    .auth-buttons a:hover,
    .user-welcome a:hover {
        opacity: 0.9;
    }

    .user-welcome a {
        background-color: #f08080;
        color: white;
        border: none;
    }

    .nav {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        background-color: #3cb371;
        padding: 10px 0;
    }

    .nav a {
        color: white;
        text-decoration: none;
        padding: 10px 15px;
        margin: 5px;
        border-radius: 4px;
        transition: background-color 0.3s;
    }

    .nav a:hover {
        background-color: #2e8b57;
    }

    .nav a.disabled {
        color: #ccc;
        cursor: not-allowed;
    }

    .card-container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
        margin-top: 30px;
    }

    .card {
        background-color: #f8fff8;
        border: 1px solid #c0eec0;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        padding: 20px;
        transition: transform 0.3s;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .card h3 {
        color: #2e8b57;
        margin-top: 0;
    }

    .login-message {
        text-align: center;
        margin: 20px 0;
        padding: 15px;
        background-color: #e0f5e0;
        border-left: 5px solid #3cb371;
    }

    footer {
        text-align: center;
        margin-top: 50px;
        padding: 20px;
        background-color: #2e8b57;
        color: white;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        header h1 {
            font-size: 2.2rem;
        }

        .auth-buttons,
        .user-welcome {
            position: static;
            justify-content: center;
            margin-top: 10px;
        }

        .nav {
            flex-direction: column;
            align-items: center;
        }

        .nav a {
            width: 90%;
            text-align: center;
        }

        .container {
            padding: 10px;
        }

        .card {
            padding: 15px;
        }
    }


    </style>
</head>
<body>
    <header>
        <h1>St. Agatha Homes</h1>
        <p>Community Portal</p>
        
        <?php if(isset($_SESSION['user_id'])): ?>
            <div class="user-welcome">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
                <a href="logout.php">Logout</a>
            </div>
        <?php else: ?>
            <div class="auth-buttons">
                <a href="login.html" class="login">Login</a>
                <a href="register.html" class="register">Register</a>
            </div>
        <?php endif; ?>
    </header>

    <div class="nav">
        <a href="index.php">Home</a>
        <a href="events.php">Events</a>
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="amenities.php">Amenities</a>
            <a href="bookings.php">Bookings</a>
            <a href="payments.php">Payments</a>
        <?php else: ?>
            <a href="#" onclick="showLoginAlert()" class="disabled">Amenities</a>
            <a href="#" onclick="showLoginAlert()" class="disabled">Bookings</a>
            <a href="#" onclick="showLoginAlert()" class="disabled">Payments</a>
        <?php endif; ?>
    </div>

    <div class="container">
        <?php if(!isset($_SESSION['user_id'])): ?>
            <div class="login-message">
                <p>Please <a href="login.html">login</a> or <a href="register.php">register</a> to access all community features</p>
            </div>
        <?php endif; ?>

        <h2>Upcoming Events</h2>
        <div class="card-container">
            <?php foreach($events as $event): ?>
                <div class="card">
                    <h3><?php echo htmlspecialchars($event['title']); ?></h3>
                    <p><strong>Date:</strong> <?php echo date('M j, Y g:i A', strtotime($event['date'])); ?></p>
                    <p><?php echo htmlspecialchars(substr($event['description'], 0, 100)); ?>...</p>
                    <a href="event_details.php?id=<?php echo $event['event_id']; ?>">View Details</a>
                </div>
            <?php endforeach; ?>
            <?php if(empty($events)): ?>
                <p>No upcoming events scheduled.</p>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> St. Agatha Homes. All rights reserved.</p>
    </footer>

    <script>
        function showLoginAlert() {
            alert('Please login to access this feature');
            window.location.href = 'login.html';
        }
    </script>
</body>
</html>