<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

$stmt = $pdo->query("
    SELECT a.*, u.name as author_name 
    FROM Announcements a
    JOIN Users u ON a.author_id = u.user_id
    ORDER BY a.date DESC
    LIMIT 5
");
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($announcements);
?>