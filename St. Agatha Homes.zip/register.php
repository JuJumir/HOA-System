<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

// Handle registration
$response = ['success' => false, 'message' => ''];

try {
    // Validate input
    $requiredFields = ['name', 'email', 'password', 'house_id', 'phase', 'block', 'lot'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception('All fields are required');
        }
    }

    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    // Check if email exists
    $stmt = $pdo->prepare("SELECT user_id FROM Users WHERE email = ?");
    $stmt->execute([$_POST['email']]);
    if ($stmt->fetch()) {
        throw new Exception('Email already registered');
    }

    // Verify the selected house exists and matches the phase/block/lot
    $stmt = $pdo->prepare("SELECT house_id, is_occupied FROM Houses WHERE house_id = ? AND phase = ? AND block = ? AND lot = ?");
    $stmt->execute([$_POST['house_id'], $_POST['phase'], $_POST['block'], $_POST['lot']]);
    $house = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$house) {
        throw new Exception('Invalid property selection');
    }

    if ($house['is_occupied']) {
        throw new Exception('This property is already occupied');
    }

    // Handle file upload
    $documentPath = '';
    if (isset($_FILES['verification_document']) && $_FILES['verification_document']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
        $fileType = $_FILES['verification_document']['type'];
        
        if (!in_array($fileType, $allowedTypes)) {
            throw new Exception('Only PDF, JPG, and PNG files are allowed');
        }

        $uploadDir = 'uploads/verification/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $extension = pathinfo($_FILES['verification_document']['name'], PATHINFO_EXTENSION);
        $documentPath = $uploadDir . uniqid() . '.' . $extension;
        
        if (!move_uploaded_file($_FILES['verification_document']['tmp_name'], $documentPath)) {
            throw new Exception('Failed to upload document');
        }
    } else {
        throw new Exception('Verification document is required');
    }

    // Hash password
    $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Start transaction
    $pdo->beginTransaction();

    try {
        // Insert user
        $stmt = $pdo->prepare("INSERT INTO Users (name, email, password, role, house_id, is_verified, verification_document) 
                              VALUES (?, ?, ?, 'homeowner', ?, 0, ?)");
        $stmt->execute([
            $_POST['name'],
            $_POST['email'],
            $hashedPassword,
            $_POST['house_id'],
            $documentPath
        ]);

        // Mark house as occupied
        $stmt = $pdo->prepare("UPDATE Houses SET is_occupied = TRUE WHERE house_id = ?");
        $stmt->execute([$_POST['house_id']]);

        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'Registration successful! Your account is pending approval.';
    } catch (Exception $e) {
        $pdo->rollBack();
        // Delete uploaded file if transaction failed
        if ($documentPath && file_exists($documentPath)) {
            unlink($documentPath);
        }
        throw $e;
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>