-- Houses (Addresses)
-- Houses Table
CREATE TABLE IF NOT EXISTS Houses (
  house_id INT AUTO_INCREMENT PRIMARY KEY,
  phase TINYINT UNSIGNED NOT NULL,
  block TINYINT UNSIGNED NOT NULL,
  lot TINYINT UNSIGNED NOT NULL,
  is_occupied BOOLEAN DEFAULT FALSE,
  property_code VARCHAR(20) GENERATED ALWAYS AS (CONCAT('P', phase, 'B', block, 'L', lot)) STORED,
  UNIQUE KEY (phase, block, lot)  -- Ensures no duplicate combinations
);

-- Users Table
CREATE TABLE IF NOT EXISTS Users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin', 'homeowner') NOT NULL DEFAULT 'homeowner',
  house_id INT NULL,
  is_verified BOOLEAN DEFAULT FALSE,
  verification_document VARCHAR(255) NULL,
  FOREIGN KEY (house_id) REFERENCES Houses(house_id) ON DELETE SET NULL	
);

-- Password Reset Tokens
CREATE TABLE IF NOT EXISTS PasswordResetTokens (
  token_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  token VARCHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);


-- Amenities (Chapel, Courts, etc.)
CREATE TABLE Amenities (
  amenity_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  booking_fee DECIMAL(10,2) DEFAULT 0
);

-- Fee Types (For Payments)
CREATE TABLE FeeTypes (
  fee_type_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE
);

-- Payments (HOA Fees via GCash, Bank Transfer)
CREATE TABLE Payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  date DATE NOT NULL,
  status ENUM('pending', 'paid', 'late') NOT NULL,
  method ENUM('GCash', 'Bank Transfer') NOT NULL,
  fee_type_id INT DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (fee_type_id) REFERENCES FeeTypes(fee_type_id) ON DELETE SET NULL
);

-- Reports (Noise Complaints, Violations)
CREATE TABLE Reports (
  report_id INT AUTO_INCREMENT PRIMARY KEY,
  reporter_id INT NOT NULL,
  violator_id INT NOT NULL,
  description TEXT NOT NULL,
  status ENUM('open', 'resolved') DEFAULT 'open',
  date DATETIME NOT NULL,
  FOREIGN KEY (reporter_id) REFERENCES Users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (violator_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

-- Maintenance Requests (Fixes, Repairs)
CREATE TABLE MaintenanceRequests (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  description TEXT NOT NULL,
  status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
  date DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

-- Amenity Bookings (Reservations)
CREATE TABLE Bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  amenity_id INT NOT NULL,
  date DATE NOT NULL,
  time TIME NOT NULL,
  status ENUM('confirmed', 'cancelled') DEFAULT 'confirmed',
  FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (amenity_id) REFERENCES Amenities(amenity_id) ON DELETE CASCADE
);

-- Events (Community Gatherings)
CREATE TABLE Events (
  event_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  description TEXT,
  date DATETIME NOT NULL,
  organizer_id INT NOT NULL,
  FOREIGN KEY (organizer_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

-- Announcements (HOA Updates)
CREATE TABLE Announcements (
  announcement_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  content TEXT NOT NULL,
  date DATETIME NOT NULL,
  author_id INT NOT NULL,
  FOREIGN KEY (author_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

-- Forum Posts (Community Discussions)
CREATE TABLE ForumPosts (
  post_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(100) NOT NULL,
  content TEXT NOT NULL,
  date DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

-- Audit Trail Table
CREATE TABLE AuditLog (
    audit_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,  -- Who made the change
    action_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    table_name VARCHAR(50) NOT NULL,  -- Which table was affected
    record_id INT NOT NULL,  -- Which record was changed
    action_type ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    field_name VARCHAR(50),  -- Which field was changed (for updates)
    old_value TEXT,  -- Previous value (for updates/deletes)
    new_value TEXT,  -- New value (for inserts/updates)
    ip_address VARCHAR(45),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE SET NULL
);




