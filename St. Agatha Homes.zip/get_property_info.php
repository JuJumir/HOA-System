<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

$houseId = $_GET['house_id'] ?? null;

if (!$houseId) {
    echo json_encode([]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM Houses WHERE house_id = ?");
$stmt->execute([$houseId]);
$property = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($property ?: []);
?>