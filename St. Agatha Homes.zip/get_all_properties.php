<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

$stmt = $pdo->query("SELECT * FROM Houses ORDER BY phase, block, lot");
$properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($properties);
?>