<?php
require 'db_connection.php'; // Make sure this returns a PDO instance

try {
    $conn = getDBConnection();

    // Set PDO to throw exceptions
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Dummy test values
    $testUserId = 3; // Change this to a valid user_id from your Users table
    $testToken = bin2hex(random_bytes(32));
    $testExpires = date("Y-m-d H:i:s", time() + 3600); // 1 hour later

    echo "<p><strong>Generated Token:</strong> $testToken</p>";
    echo "<p><strong>Expires At:</strong> $testExpires</p>";

    // Insert test token
    $stmt = $conn->prepare("INSERT INTO PasswordResetTokens (user_id, token, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$testUserId, $testToken, $testExpires]);

    // Check success
    $insertId = $conn->lastInsertId();
    if ($insertId) {
        echo "<p style='color:green;'>✅ Token inserted successfully! ID: $insertId</p>";
    } else {
        echo "<p style='color:red;'>❌ Insert failed. No insert ID returned.</p>";
    }

} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
