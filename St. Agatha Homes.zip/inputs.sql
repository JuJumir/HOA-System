SELECT * FROM users;
 DELETE FROM Users WHERE name='Admin'; 
INSERT INTO Users (name, email, password, role, is_verified)
VALUES (
    'Admin', 
    'admin@hoa.com', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- "password" hashed
    'admin', 
    TRUE
);

INSERT INTO Houses (phase, block, lot) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1);


SELECT * FROM Houses;

 DELETE FROM Houses WHERE Phase = 2; 
 
 SHOW CREATE TABLE PasswordResetTokens;
 
 SELECT * FROM PasswordResetTokens 
WHERE user_id = '3' 
AND used = FALSE;
 