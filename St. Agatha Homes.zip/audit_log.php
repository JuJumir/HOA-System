<?php
// Function to log actions to the audit log
function logAudit($userId, $action, $details = null) {
    $pdo = require 'db_connection.php';
    
    $stmt = $pdo->prepare("INSERT INTO AuditLog (user_id, action, action_details, ip_address, user_agent) 
                          VALUES (?, ?, ?, ?, ?)");
    
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    
    $stmt->execute([
        $userId,
        $action,
        $details,
        $ipAddress,
        $userAgent
    ]);
}

// Create the audit log table if it doesn't exist (run this once)
function createAuditLogTable() {
    $pdo = require 'db_connection.php';
    
    $sql = "CREATE TABLE IF NOT EXISTS AuditLog (
        log_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        action VARCHAR(50) NOT NULL,
        action_details TEXT,
        ip_address VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES Users(user_id)
    )";
    
    $pdo->exec($sql);
}

// Uncomment this line to create the table (run once, then comment out again)
// createAuditLogTable();
?>