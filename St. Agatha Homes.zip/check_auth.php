<?php
header('Content-Type: application/json');
session_start();

$response = [
    'authenticated' => false,
    'name' => '',
    'is_verified' => false,
    'house_id' => null
];

if (isset($_SESSION['user_id'])) {
    // Database connection
    $host = 'localhost';
    $dbname = 'hoa';
    $username = 'root';
    $password = '';
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    $stmt = $pdo->prepare("SELECT name, is_verified, house_id FROM Users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $response['authenticated'] = true;
        $response['name'] = $user['name'];
        $response['is_verified'] = (bool)$user['is_verified'];
        $response['house_id'] = $user['house_id'];
    }
}

echo json_encode($response);
?>