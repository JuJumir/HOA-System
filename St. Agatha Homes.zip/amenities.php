<?php
session_start();
require_once 'db_connection.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Get amenities data
$amenities = [];
try {
    $conn = getDBConnection();
    $stmt = $conn->query("SELECT * FROM Amenities ORDER BY name");
    $amenities = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error loading amenities: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>St. Agatha Homes - Amenities</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            color: #2f4f2f;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background-color: #2e8b57;
            color: white;
            padding: 30px 20px 20px;
            text-align: center;
            position: relative;
        }

        header h1 {
            font-family: 'Great Vibes', cursive;
            font-size: 3rem;
            margin: 0;
        }

        .user-welcome {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .user-welcome a {
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            font-weight: bold;
            background-color: #f08080;
            color: white;
            border: none;
            transition: opacity 0.3s;
        }

        .user-welcome a:hover {
            opacity: 0.9;
        }

        .nav {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            background-color: #3cb371;
            padding: 10px 0;
        }

        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .nav a:hover {
            background-color: #2e8b57;
        }

        .nav a.current {
            background-color: #2e8b57;
            font-weight: bold;
        }

        /* Amenities Specific Styles */
        .amenities-header {
            text-align: center;
            margin: 30px 0;
            padding: 20px;
            background-color: #e0f5e0;
            border-radius: 8px;
        }

        .amenities-header h2 {
            color: #2e8b57;
            margin-top: 0;
            font-size: 2rem;
        }

        .amenities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            margin-top: 20px;
        }

        .amenity-card {
            background-color: #f8fff8;
            border: 1px solid #c0eec0;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .amenity-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
        }

        .amenity-image {
            height: 200px;
            background-color: #2e8b57;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .amenity-image i {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            color: #2e8b57;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }

        .amenity-info {
            padding: 20px;
        }

        .amenity-info h3 {
            color: #2e8b57;
            margin-top: 0;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .amenity-info p {
            line-height: 1.6;
        }

        .amenity-meta {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px dashed #c0eec0;
            color: #5a8f5a;
        }

        .book-btn {
            display: inline-block;
            padding: 8px 20px;
            background-color: #3cb371;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .book-btn:hover {
            background-color: #2e8b57;
        }

        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            background-color: #2e8b57;
            color: white;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            header h1 {
                font-size: 2.2rem;
            }

            .user-welcome {
                position: static;
                justify-content: center;
                margin-top: 10px;
            }

            .nav {
                flex-direction: column;
                align-items: center;
            }

            .nav a {
                width: 90%;
                text-align: center;
            }

            .amenities-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>St. Agatha Homes</h1>
        <p>Community Portal</p>
        
        <div class="user-welcome">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <div class="nav">
        <a href="index.php">Home</a>
        <a href="events.php">Events</a>
        <a href="amenities.php" class="current">Amenities</a>
        <a href="bookings.php">Bookings</a>
        <a href="payments.php">Payments</a>
    </div>

    <div class="container">
        <div class="amenities-header">
            <h2><i class="fas fa-swimming-pool"></i> Community Amenities</h2>
            <p>Explore and book our premium community facilities</p>
        </div>

        <div class="amenities-grid">
            <?php foreach($amenities as $amenity): ?>
                <div class="amenity-card">
                    <div class="amenity-image" style="background-image: url('<?php echo htmlspecialchars($amenity['image_url'] ?: 'images/default-amenity.jpg'); ?>')">
                        <i class="<?php echo htmlspecialchars($amenity['icon_class'] ?: 'fas fa-star'); ?>"></i>
                    </div>
                    <div class="amenity-info">
                        <h3>
                            <i class="<?php echo htmlspecialchars($amenity['icon_class'] ?: 'fas fa-star'); ?>"></i>
                            <?php echo htmlspecialchars($amenity['name']); ?>
                        </h3>
                        <p><?php echo htmlspecialchars($amenity['description']); ?></p>
                        
                        <div class="amenity-meta">
                            <span><i class="fas fa-clock"></i> <?php echo htmlspecialchars($amenity['operating_hours'] ?: '8:00 AM - 10:00 PM'); ?></span>
                            <span><i class="fas fa-users"></i> Capacity: <?php echo htmlspecialchars($amenity['capacity'] ?: 'Varies'); ?></span>
                        </div>
                        
                        <a href="book_amenity.php?id=<?php echo $amenity['amenity_id']; ?>" class="book-btn">Book Now</a>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <?php if(empty($amenities)): ?>
                <p>No amenities currently available.</p>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> St. Agatha Homes. All rights reserved.</p>
    </footer>
</body>
</html>