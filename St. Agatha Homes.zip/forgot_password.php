<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        h2 {
            text-align: center;
            color: #2e7d32;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="email"] {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #2e7d32;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }
        .message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 4px;
        }
        .success {
            background-color: #dff0d8;
            color: #3c763d;
        }
        .error {
            background-color: #f2dede;
            color: #a94442;
        }
        .bottom-links {
            text-align: center;
            margin-top: 1.5rem;
        }
        .bottom-links a {
            color: #2d89ef;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .bottom-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Forgot Password</h2>
    <form method="POST" action="send_reset_link.php">
        <div class="form-group">
            <label for="email">Enter your email address:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <button type="submit">Send Reset Link</button>
    </form>
    
    <?php if (isset($_GET['message'])): ?>
        <div class="message <?php echo $_GET['status']; ?>">
            <?php echo htmlspecialchars($_GET['message']); ?>
        </div>
    <?php endif; ?>
    
    <p>Remember your password? <a href="login.html">Login here</a></p>
</body>
</html>