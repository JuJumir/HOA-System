<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

$response = ['success' => false, 'message' => ''];

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['user_id'])) {
        throw new Exception('User ID is required');
    }
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Update user status
    $stmt = $pdo->prepare("UPDATE Users SET is_verified = ? WHERE user_id = ?");
    $stmt->execute([$data['approve'], $data['user_id']]);
    
    // If rejecting, free up the house
    if (!$data['approve']) {
        // Get user's house_id first
        $stmt = $pdo->prepare("SELECT house_id FROM Users WHERE user_id = ?");
        $stmt->execute([$data['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && $user['house_id']) {
            $stmt = $pdo->prepare("UPDATE Houses SET is_occupied = FALSE WHERE house_id = ?");
            $stmt->execute([$user['house_id']]);
        }
    }
    
    $pdo->commit();
    $response['success'] = true;
    $response['message'] = $data['approve'] ? 'User approved successfully' : 'User rejected successfully';
} catch (Exception $e) {
    $pdo->rollBack();
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>