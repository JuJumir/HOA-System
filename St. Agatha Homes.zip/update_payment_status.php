<?php
session_start();
require_once 'db_connection.php';

// Only treasurer can update status
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'treasurer') {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['payment_id']) || !isset($data['status'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid data']));
}

try {
    $conn = getDBConnection();
    $stmt = $conn->prepare("
        UPDATE Payments 
        SET status = :status 
        WHERE payment_id = :payment_id
    ");
    $stmt->execute([
        'status' => $data['status'],
        'payment_id' => $data['payment_id']
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Payment status updated']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>