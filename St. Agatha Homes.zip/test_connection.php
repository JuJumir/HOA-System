
<?php


require_once 'db_connection.php';
$conn = getDBConnection();
echo "Connected successfully!";

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Optional: Test query
$stmt = $conn->query("SHOW TABLES");
print_r($stmt->fetchAll());
?>