<?php
// audit_log_view.php
require_once 'auth_check.php'; // Ensure user is admin
require_once 'db_connection.php';

$pdo = getDBConnection();
$stmt = $pdo->query("SELECT a.*, u.email, u.name 
                    FROM AuditLog a
                    JOIN Users u ON a.user_id = u.user_id
                    ORDER BY a.created_at DESC
                    LIMIT 100");
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Audit Log</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Audit Log</h1>
    <table>
        <tr>
            <th>Timestamp</th>
            <th>User</th>
            <th>Email</th>
            <th>Action</th>
            <th>Details</th>
            <th>IP Address</th>
        </tr>
        <?php foreach ($logs as $log): ?>
        <tr>
            <td><?= htmlspecialchars($log['created_at']) ?></td>
            <td><?= htmlspecialchars($log['name']) ?></td>
            <td><?= htmlspecialchars($log['email']) ?></td>
            <td><?= htmlspecialchars($log['action']) ?></td>
            <td><?= htmlspecialchars($log['action_details']) ?></td>
            <td><?= htmlspecialchars($log['ip_address']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>