<?php
header('Content-Type: application/json');
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';

$response = ['success' => false, 'message' => 'Invalid credentials'];

try {
    // Connect to database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get input data
    $input = file_get_contents('php://input');
    if (empty($input)) {
        throw new Exception('No input received');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON input');
    }

    // Validate input
    if (empty($data['email']) || empty($data['password'])) {
        throw new Exception('Email and password are required');
    }

    // Prepare and execute query
    $stmt = $pdo->prepare("SELECT user_id, name, email, password, role, is_verified FROM Users WHERE email = ?");
    $stmt->execute([$data['email']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception('User not found');
    }

    // Verify password
    if (!password_verify($data['password'], $user['password'])) {
        throw new Exception('Incorrect password');
    }

    // Check verification status
    if (!$user['is_verified']) {
        $response['message'] = 'Your account is pending approval. Please wait for admin verification.';
    } else {
        // Set session variables
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        
        $response['success'] = true;
        $response['message'] = 'Login successful';
        $response['user'] = [
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role']
        ];
    }
} catch (PDOException $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>