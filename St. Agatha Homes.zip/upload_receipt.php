<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['receipt'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid request']));
}

$target_dir = "uploads/receipts/";
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}

$file_ext = pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION);
$file_name = 'receipt_' . $_SESSION['user_id'] . '_' . time() . '.' . $file_ext;
$target_file = $target_dir . $file_name;

if (move_uploaded_file($_FILES['receipt']['tmp_name'], $target_file)) {
    try {
        $conn = getDBConnection();
        $stmt = $conn->prepare("
            INSERT INTO Payments (user_id, amount, date, status, method, receipt_path)
            VALUES (:user_id, :amount, CURDATE(), 'pending', :method, :receipt_path)
        ");
        
        // You might want to get the actual amount due from your database
        $stmt->execute([
            'user_id' => $_SESSION['user_id'],
            'amount' => 1500.00, // Example amount
            'method' => $_POST['method'],
            'receipt_path' => $target_file
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Receipt uploaded successfully']);
    } catch (PDOException $e) {
        unlink($target_file); // Delete the uploaded file if DB insert fails
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Error uploading file']);
}
?>