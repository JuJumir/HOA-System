<?php
require 'db_connection.php';

if (!isset($_GET['token'])) {
    die("No token provided.");
}

$token = $_GET['token'];

try {
    $conn = getDBConnection();
    
    // 1. Verify token validity
    $stmt = $conn->prepare("
        SELECT prt.user_id, prt.expires_at, u.email
        FROM PasswordResetTokens prt
        JOIN Users u ON prt.user_id = u.user_id
        WHERE prt.token = ? 
        AND prt.used = FALSE
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $tokenData = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tokenData) {
        die("Invalid or expired token. Please request a new password reset.");
    }

    // Check expiration
    if (strtotime($tokenData['expires_at']) < time()) {
        die("Token has expired. Please request a new password reset.");
    }

    // 2. Handle password change form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newPassword = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // Validate passwords
        if (empty($newPassword)) {
            $error = "Password cannot be empty";
        } elseif (strlen($newPassword) < 8) {
            $error = "Password must be at least 8 characters";
        } elseif ($newPassword !== $confirmPassword) {
            $error = "Passwords do not match";
        } else {
            // Update password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE Users SET password = ? WHERE user_id = ?");
            $stmt->execute([$hashedPassword, $tokenData['user_id']]);
            
            // Mark token as used
            $stmt = $conn->prepare("UPDATE PasswordResetTokens SET used = TRUE WHERE token = ?");
            $stmt->execute([$token]);
            
            // Redirect with success message
            header("Location: login.php?message=Password updated successfully&status=success");
            exit();
        }
    }

} catch (Exception $e) {
    error_log("Password reset error: " . $e->getMessage());
    die("System error. Please try again later.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .password-form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h2 {
            color: #2e7d32;
            margin-top: 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #2e7d32;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        .error {
            color: #d9534f;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #f2dede;
            border-radius: 4px;
        }
        .success {
            color: #3c763d;
            background-color: #dff0d8;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .bottom-links {
            text-align: center;
            margin-top: 1.5rem;
        }
        .bottom-links a {
            color: #2d89ef;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .bottom-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="password-form">
        <h2>Reset Password</h2>
        <p>Welcome, <?php echo htmlspecialchars($tokenData['email']); ?>. Set your new password below.</p>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="password">New Password (min 8 characters):</label>
                <input type="password" id="password" name="password" required minlength="8">
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
            </div>
            <button type="submit">Change Password</button>
        </form>
    </div>
</body>
</html>