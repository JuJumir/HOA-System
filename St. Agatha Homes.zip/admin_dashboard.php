<?php
require_once 'admin_check.php'; // This ensures only admins can access

// Get all data we'll need
require_once 'db_connection.php';
$conn = getDBConnection();

// Get pending approvals
$pending = [];
$users = [];
$properties = [];

try {
    // Pending Approvals
    $stmt = $conn->query("
        SELECT u.user_id, u.name, u.email, u.verification_document, h.property_code 
        FROM Users u 
        LEFT JOIN Houses h ON u.house_id = h.house_id 
        WHERE u.is_verified = FALSE
    ");
    $pending = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // All Users
    $stmt = $conn->query("
        SELECT u.user_id, u.name, u.email, u.role, u.is_verified, h.property_code 
        FROM Users u 
        LEFT JOIN Houses h ON u.house_id = h.house_id
    ");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // All Properties
    $stmt = $conn->query("SELECT * FROM Houses ORDER BY phase, block, lot");
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
    body {
        font-family: 'Segoe UI', cursive;
        margin: 0;
        padding: 0;
        background-color: #f0fff0;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    header {
        background-color: #4caf50;
        color: white;
        padding: 1rem;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }

    header h1 {
        margin: 0;
        font-size: 1.8rem;
    }

    .logout-btn {
        background: white;
        color: #4caf50;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        cursor: pointer;
        font-family: inherit;
    }

    .tabs {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 1rem;
        border-bottom: 1px solid #ddd;
    }

    .tab {
        padding: 10px 20px;
        cursor: pointer;
        background: #e8f5e9;
        margin-right: 5px;
        border-radius: 4px 4px 0 0;
        font-family: inherit;
    }

    .tab.active {
        background: #4caf50;
        color: white;
    }

    .tab-content {
        display: none;
        background: white;
        padding: 20px;
        border-radius: 0 0 4px 4px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        overflow-x: auto;
    }

    .tab-content.active {
        display: block;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.9rem;
        word-break: break-word;
    }

    th, td {
        padding: 10px 12px;
        border-bottom: 1px solid #ccc;
        text-align: left;
    }

    th {
        background-color: #e8f5e9;
        font-weight: bold;
    }

    .action-btn {
        padding: 6px 10px;
        margin: 0 4px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-family: inherit;
    }

    .approve-btn {
        background-color: #66bb6a;
        color: white;
    }

    .reject-btn {
        background-color: #ef5350;
        color: white;
    }

    .view-btn {
        background-color: #26c6da;
        color: white;
    }

    #documentModal {
        display: none;
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.8);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }

    #documentModal iframe {
        width: 90%;
        height: 80vh;
        border: none;
    }

    @media (max-width: 768px) {
        header {
            align-items: center;
            text-align: center;
        }

        .tabs {
            flex-direction: column;
        }

        .tab {
            margin-right: 0;
            margin-bottom: 5px;
        }

        table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }

        .logout-btn {
            width: 100%;
            text-align: center;
        }
    }
</style>

</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <div>
            <span style="color: white; margin-right: 15px;">Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
            <button class="logout-btn" id="logoutBtn">Logout</button>
        </div>
    </header>
    
    <div class="container">
        <div class="tabs">
            <div class="tab active" data-tab="pending">Pending Approvals</div>
            <div class="tab" data-tab="users">All Users</div>
            <div class="tab" data-tab="properties">Properties</div>
        </div>
        
        <div class="tab-content active" id="pending-tab">
            <h2>Pending User Approvals</h2>
            <table id="pendingTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Property</th>
                        <th>Document</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($pending as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['property_code'] ?? 'N/A'); ?></td>
                        <td>
                            <button class="view-btn" onclick="viewDocument('<?php echo htmlspecialchars($user['verification_document']); ?>')">
                                View
                            </button>
                        </td>
                        <td>
                            <button class="approve-btn" onclick="approveUser(<?php echo $user['user_id']; ?>)">Approve</button>
                            <button class="reject-btn" onclick="rejectUser(<?php echo $user['user_id']; ?>)">Reject</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($pending)): ?>
                    <tr>
                        <td colspan="5">No pending approvals</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="tab-content" id="users-tab">
            <h2>All Users</h2>
            <table id="usersTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Property</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['role']); ?></td>
                        <td><?php echo $user['is_verified'] ? 'Verified' : 'Pending'; ?></td>
                        <td><?php echo htmlspecialchars($user['property_code'] ?? 'N/A'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="tab-content" id="properties-tab">
            <h2>All Properties</h2>
            <table id="propertiesTable">
                <thead>
                    <tr>
                        <th>Property Code</th>
                        <th>Phase</th>
                        <th>Block</th>
                        <th>Lot</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($properties as $property): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($property['property_code']); ?></td>
                        <td><?php echo htmlspecialchars($property['phase']); ?></td>
                        <td><?php echo htmlspecialchars($property['block']); ?></td>
                        <td><?php echo htmlspecialchars($property['lot']); ?></td>
                        <td><?php echo $property['is_occupied'] ? 'Occupied' : 'Available'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for viewing document -->
    <div id="documentModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.8); z-index: 1000; justify-content: center; align-items: center;">
        <div style="background: white; padding: 20px; max-width: 80%; max-height: 80%; overflow: auto;">
            <button id="closeModal" style="float: right; margin-bottom: 10px;">Close</button>
            <iframe id="documentViewer" src="" style="width: 800px; height: 600px; border: none;"></iframe>
        </div>
    </div>

    <script>
        // Tab switching
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                this.classList.add('active');
                document.getElementById(`${this.dataset.tab}-tab`).classList.add('active');
            });
        });
        
        // Logout
        document.getElementById('logoutBtn').addEventListener('click', function() {
            window.location.href = 'logout.php';
        });
        
        // Close modal
        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('documentModal').style.display = 'none';
        });
        
        function viewDocument(path) {
            const modal = document.getElementById('documentModal');
            const viewer = document.getElementById('documentViewer');
            
            viewer.src = path;
            modal.style.display = 'flex';
        }
        
        function approveUser(userId) {
            updateUserStatus(userId, true);
        }
        
        function rejectUser(userId) {
            updateUserStatus(userId, false);
        }
        
        function updateUserStatus(userId, approve) {
            fetch('update_user_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_id: userId,
                    approve: approve
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    window.location.reload(); // Refresh the page to see changes
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        }
    </script>
</body>
</html>