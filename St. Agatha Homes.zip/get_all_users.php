<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'hoa';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

$stmt = $pdo->query("
    SELECT u.user_id, u.name, u.email, u.role, u.is_verified, h.property_code 
    FROM Users u 
    LEFT JOIN Houses h ON u.house_id = h.house_id
");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($users);
?>