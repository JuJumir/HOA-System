<?php
header('Content-Type: application/json');

// Include the database connection
require_once 'db_connection.php';

try {
    // Get database connection
    $conn = getDBConnection();

    // Get available properties (not occupied)
    $stmt = $conn->prepare("
        SELECT house_id, phase, block, lot, property_code, is_occupied 
        FROM Houses 
        WHERE is_occupied = FALSE 
        ORDER BY phase, block, lot
    ");
    
    $stmt->execute();
    $houses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($houses)) {
        echo json_encode(['error' => 'No available properties found']);
    } else {
        echo json_encode($houses);
    }

} catch (PDOException $e) {
    echo json_encode([
        'error' => 'Database error',
        'details' => $e->getMessage()
    ]);
}
?>